
bar3(matrix)
rotate3d