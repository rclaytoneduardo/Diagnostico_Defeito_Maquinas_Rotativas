load('matrix181130201208.mat')
bar3(matrix)
rotate3d